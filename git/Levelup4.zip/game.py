import pygame
from core import StageManager, Menu, StageType
from stages import Splash, About, CodeChallenge01, CodeChallenge02, CodeChallenge03, Congrats


class Game(object):

    def __init__(self, screen):
        self._screen = screen
        self._clock = pygame.time.Clock()

        self.running = False

        self._stage_manager = StageManager(screen)
        self._stage_manager.add(Splash)
        self._stage_manager.add(About)
        self._stage_manager.add(CodeChallenge01)
        self._stage_manager.add(CodeChallenge02)
        self._stage_manager.add(CodeChallenge03)
        self._stage_manager.add(Congrats)

    def is_splash(self):
        return self._stage_manager.current_stage_type == StageType.splash_screen

    def start(self):
        self.running = True

        self._stage_manager.start()

        while self.running:

            dt = self._clock.tick(60)

            for event in pygame.event.get():

                if event.type == pygame.QUIT:
                    self.running = False
                if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE and self.is_splash() :
                    self.running = False
                if event.type == pygame.KEYDOWN and event.key == pygame.K_F12:
                    self.running = False

                if self.running:
                    self._stage_manager.update(event)

            pygame.display.flip()


if __name__ == '__main__':
    pygame.init()
    screen = pygame.display.set_mode((1920, 1080), pygame.FULLSCREEN)
    pygame.display.set_caption("Pygame labs")
    pygame.mouse.set_visible(False)
    game = Game(screen)
    game.start()

