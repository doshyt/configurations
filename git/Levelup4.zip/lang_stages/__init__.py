from .lang_challenges import LangChallengeBase
from .lang_challenges import LangChallengeGeneric
