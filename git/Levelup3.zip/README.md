# Level up - THE game

A game (or sort of) to be used on development events by Snow Software.

## Things you need to install

### pip

https://pip.pypa.io/en/stable/installing/

### Packages

Enum: `pip install enum`

PyMongo: `pip install pymongo`

validate_email: `pip install validate_email`

### MongoDB

You can download the community edition here:

https://www.mongodb.com/download-center#community

## Getting started

Clone the project and use the development branch to get the latest and the greatest!!

### Starting the MongoDB server

MongoDB will try to store all the databases at the drive you are currently on, inside the folders **data/db** for if you are on drive c:
you will need to create `c:\data\db` before starting the mongDB daemon.

`mongod --noauth --directoryperbd`

This command will start the server without security and it will create a single directory for every database created on a
separated folder. MongoDB runs by default on port 27017, if the windows firewall ask something just authorize to use that port and you are good to go! :metal:

If you wanna see things that are being created on the database you can use the mongodb client for it, type: `mongo`

The game will create a database called `levelup` and a collection called `players`. To get a list of all players you can do:

`use levelup`

`db.players.find()`
