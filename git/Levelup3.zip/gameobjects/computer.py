import pygame
import os
from pygame import mixer

class Computer(pygame.sprite.Sprite):

    def __init__(self, code_map, font, color, *sprite_group):
        super(Computer, self).__init__(*sprite_group)

        self._font = font
        self._color = color
        self.image = pygame.Surface((700, 900), pygame.SRCALPHA)
        self.image.fill((255, 255, 255, 0))

        self.rect = pygame.rect.Rect((650, 35), self.image.get_size())

        self._button_font = pygame.font.Font(os.path.join('fonts','Roboto-Regular.ttf'), 24)

        self._code_map = code_map
        self._reset()

        sound_dir = os.path.join(os.path.abspath(os.curdir),'sounds')
        self.select_sound = mixer.Sound(os.path.join(sound_dir, 'select.wav'))

    def _reset(self):
        """
            Reset the game, it will set all the valid keys available to True and
            clear the resulted code.
            After everything being reset it will call the render method which will
            refresh the content of the result code rect.
        """
        self.validkeys = {pygame.K_0: (0, True),
                          pygame.K_1: (1, True),
                          pygame.K_2: (2, True),
                          pygame.K_3: (3, True),
                          pygame.K_4: (4, True),
                          pygame.K_5: (5, True),
                          pygame.K_6: (6, True),
                          pygame.K_7: (7, True),
                          pygame.K_8: (8, True),
                          pygame.K_9: (9, True),}

        self._map_valid_keys()

        self._result_code = {}
        self._initial_line = 1
        self._allow_undo = False
        self.render()

    def _map_valid_keys(self):
        """
            Set False to items in the validkeys dictionary that are
            not in the source code map.
        """
        data = [{self.validkeys[x][0]: x} for x in self.validkeys]
        for k in data:
            key, val = k.items()[0]
            if not self._code_map.get(key):
                self.validkeys[val] = (k, False)


    def _get_possible_key_values(self, key):
        """
            Returns the key that the user can input and return if the are available
            or not. It returns a array of tuples with the first element
            containing a tutle with the code line number and a flag indicating if its
            available and the second element is a actual code key that was pressed.
        """

        return [(self.validkeys[x][0], x) for x in self.validkeys.keys() if key[x] and self.validkeys[x][1]]

    def _is_code_completed(self):
        """
            Check if the source code is completed.
        """

        parts_left = [x for x in self.validkeys.keys() if self.validkeys[x][1]]
        return True if len(parts_left) <= 0 else False


    def update(self, dt, game):
        """
            Update all the game elements.
        """

        key = pygame.key.get_pressed()

        if key[pygame.K_u]:
            self._undo()
        elif key[pygame.K_F2]:
            self._reset()
        elif key[pygame.K_F5]:
            self._run()
        else:

            possible_key_values = self._get_possible_key_values(key)

            if len(possible_key_values) > 0:

                val, key_pressed = possible_key_values[0]
                line = (self._code_map[val][1], self._code_map[val][0]) if val in self._code_map else None

                if line != None:
                    self._result_code[self._initial_line] = (key_pressed, val, line[1], line[0])
                    self.validkeys[key_pressed] = (val, False)
                    self._initial_line += 1
                    self._allow_undo = True
                    self.select_sound.play()
                    self.render()


    def _undo(self):
        """
            Undo the user's last action. Only one undo is allowed at the time.
        """

        if len(self._result_code.keys()) == 0:
            return

        last_key = self._result_code.keys()[-1]

        if last_key != None and self._allow_undo:
            key_pressed, val, line_number, line = self._result_code[last_key]

            self._allow_undo = False
            self.validkeys[key_pressed] = (val, True)
            self._result_code.pop(last_key)
            self._initial_line -= 1
            self.render()


    def _run(self):
        if(self._is_code_completed()):
            is_correct = False
            correct_order = sorted([self._code_map[x][0] for x in self._code_map.keys()])
            result_data = [self._result_code[x][2] for x in self._result_code.keys()]
            
            if len(correct_order) != len(result_data):
                is_correct = False
            else:
                for index in range(0, len(correct_order)):
                    if correct_order[index] == result_data[index]:
                        is_correct = True
                    else:
                        is_correct = False
              
            print "Result: ", is_correct


    def render(self):
        """
            Refresh the surface with new data.
        """

        start = 0
        self.image.fill((255, 255, 255, 0))

        for key in self._result_code.keys():

            text = self._font.render(self._result_code[key][3], 0, self._color)
            self.image.blit(text, (10, start))
            start += 40

        if self._is_code_completed():
            start += 70
            button = pygame.rect.Rect((150, start), (250,50))
            text = self._button_font.render("[F5] RUN", 0, (0,0,0))
            self.button = pygame.draw.rect(self.image, self._color, button, 0)
            self.image.blit(text, (220, start+10))
