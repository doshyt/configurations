import pygame
import os

class PygameTextBox(pygame.sprite.Sprite):

    def __init__(self, dimensions, position, color, sprite_group, focused=False, flags=0, only_numbers=False, with_errors=False, visible=True):
        super(PygameTextBox, self).__init__(sprite_group)

        r, g, b = color
        self.bg_color_selected = (r, g, b, 50)
        self.bg_color_unselected = (r, g, b, 0)
        self.fg_color = color
        self.bg_error = (204, 0, 0, 10)

        font_path = os.path.join(os.curdir, "fonts", "Roboto-Bold.ttf")
        self.font = pygame.font.Font(font_path, 46)

        self.image = pygame.Surface(dimensions, flags, 32)
        self.rect = self.image.get_rect()

        top, left = position
        self.rect.top = top
        self.rect.left = left

        self.content = ""
        self.has_focus = focused

        self._only_numbers = only_numbers

        self._is_valid = True
        self._with_errors = with_errors
        self._is_visible = visible


    """
        Returns the if the content of the input box is valid.
        It is intended to run after the validators.
    """
    @property
    def is_valid(self):
        return self._is_valid

    @is_valid.setter
    def is_valid(self, value):
        self._is_valid = value

    """
        Render the input box and the updated content.
        It will be highlighted is the textbox has focus and it will be
        marked with red color if the textbox content is not valid.
    """
    def render(self, with_errors = False):
        bg, fg = (self.bg_color_selected, self.fg_color) if self.has_focus else (self.bg_color_unselected, self.fg_color)

        if self._with_errors and self.has_focus and not self.is_valid:
            bg = (204, 0, 0, 50)


        self.image.fill(bg)
        text = self.font.render(self.content, 0, self.fg_color)
        self.image.blit(text, (10, 7))

    """
        It will be called when the sprite group is called, it just run the
        render() method to refresh the textbox content.
    """
    def update(self, time):
        if self._is_visible:
            self.render()

    """
        Clear the textbox content
    """
    def clear(self):
        self.set_text("")


    """
        Set the textbox content
    """
    def set_text(self, value):
        self.content = value


    """
        Returns the textbox content.
    """
    def get_text(self):
        return self.content

    """
        Returns a flag indicating if the textbox has focus or not.
    """
    @property
    def has_focus(self):
        return self._has_focus


    @has_focus.setter
    def has_focus(self, value):
        self._has_focus = value


    """
        Helper method to detect if the player pressed left or right shift key.
    """
    def _mod_shift(self):
        return pygame.key.get_mods() & (pygame.KMOD_LSHIFT | pygame.KMOD_RSHIFT)


    """
        Helper method to detect if the player pressed left or right alt key.
    """
    def _mod_alt(self):
        return (pygame.key.get_mods() & (pygame.KMOD_LALT | pygame.KMOD_RALT)) | 313

    def _backspace_or_return(self, event):
       return (event.key == pygame.K_RETURN or event.key == pygame.K_BACKSPACE)

    def _is_only_numbers(self, event):
       return (event.key >= pygame.K_0 and event.key <= pygame.K_9) 


    """
        Textbox event handler method.
    """
    def handle_events(self, event):

        if event.type != pygame.KEYDOWN or not self.has_focus:
            return

        if (event.key == pygame.K_TAB or event.key == pygame.K_ESCAPE):
            return

        if self._only_numbers and not (self._is_only_numbers(event) or self._backspace_or_return(event)):
            return


        if self._mod_alt() and event.key == pygame.K_2 and not self._only_numbers:
            self.content += chr(pygame.K_AT)
        elif self._mod_shift() and event.key == 47 and not self._only_numbers:
            self.content += chr(pygame.K_UNDERSCORE)
        elif event.key == 47 and not self._only_numbers:
            self.content += chr(pygame.K_MINUS)
        elif event.key == pygame.K_BACKSPACE:
            self.content = self.content[:-1]
        elif event.key == pygame.K_RETURN:
            return
        elif event.key == 59 or event.key == 246:
            self.content += "o" 
        elif event.key == 91 or event.key == 229:
            self.content += "a" 
        elif event.key == 39 or event.key == 228:
            self.content += "a"
        # TODO: add Shift +'.' key shortcut description for underscore to the about screen
        # assets/snow_game_backgrounds-d01_002_03.png or use a different shortcut
        elif self._mod_shift() and event.key == 46 and not self._only_numbers:
            self.content += chr(pygame.K_UNDERSCORE)
        elif event.key <= 127 and event.key > 0:
            if self._only_numbers and len(self.content) == 2:
                return

            if self._mod_shift() and (event.key >= pygame.K_a and event.key <= pygame.K_z):
                self.content +=chr(event.key).upper()
            else:
                self.content += chr(event.key)
