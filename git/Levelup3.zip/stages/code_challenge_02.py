from gameobjects import CodeChallengeBase 


class CodeChallenge02(CodeChallengeBase):

    def __init__(self, screen, *args):
        super(CodeChallenge02, self).__init__(screen, "csharp_challenge.cs")
        self.stage_name = "challenge_002"

    
