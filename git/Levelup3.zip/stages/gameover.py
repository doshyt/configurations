import pygame
import os

from core import Stage, StageType

class GameOver(Stage):

    def __init__(self, screen, *args):
        super(GameOver, self).__init__(screen)
        bg_path = os.path.join(os.curdir, "assets", "snow_game_backgrounds-d01_002_02.png")
        bg = pygame.image.load(bg_path)
        screen.blit(bg, (0,0))


    @property
    def type(self):
        return StageType.sub_stage


    def update(self, event):
        self._event_handler(event)


    def _event_handler(self, event):

        if event.type != pygame.KEYDOWN:
            return

        if event.key == pygame.K_t:
            self._completed = True
            self.retry_when_completed = True

        if event.key == pygame.K_ESCAPE:
            self._completed = True
            self.leave_when_completed = True

            

