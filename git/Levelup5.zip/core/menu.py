import pygame
import os

from . import Stage, StageType, MenuItem
from pygame.event import Event
from pygame import mixer

class Menu(Stage):

    def __init__(self, screen):

        super(Menu, self).__init__(screen)

        self._menu_items = [
                MenuItem("Start", lambda: setattr(self, '_completed', True)),
                MenuItem("Credits", None),
                MenuItem("Quit", lambda: pygame.event.post(Event(pygame.QUIT))),
        ]

        self._screen = screen
        self._default_font = pygame.font.Font(pygame.font.get_default_font(), 24)
        self._pointer = 0
        self._last_index = len(self._menu_items) - 1

        sound_dir = os.path.join(os.path.abspath(os.curdir),'sounds')
        self.sound = mixer.Sound(os.path.join(sound_dir, 'select.wav'))


    @property
    def type(self):
        return StageType.splash_screen


    def _event_handler(self, event):

        if len(self._menu_items) == -1:
            raise Exception("There isn't any item in the menu.")

        if event.type != pygame.KEYDOWN or self._completed:
            return

        if event.key == pygame.K_DOWN:
            if self._pointer == self._last_index:
                self._pointer = 0
            else:
                self._pointer += 1

            self.sound.play()

        if event.key == pygame.K_UP:
            if self._pointer == 0:
                self._pointer = self._last_index
            else:
                self._pointer -= 1

            self.sound.play()

        if event.key == pygame.K_RETURN:
            current_item = self._menu_items[self._pointer]
            current_item.action()



    def _add_item(self, item):

        self._menu_items.append(item)
        self._last_index = len(self._menu_items) - 1


    def update(self, tick):

        self._screen.fill((0, 0, 0))
        row = 0

        for index, item in enumerate(self._menu_items):
            color = (255, 255, 255) if index != self._pointer else (128, 255, 0)
            text = self._default_font.render(item.text, 0, color)
            row += 50
            self._screen.blit(text, (10, row))

