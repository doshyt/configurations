from pymongo import MongoClient

class DataManager():

    def __init__(self, db_name="levelup"):
        self.db_name = db_name


    def _connect(self):
        return MongoClient('mongodb://localhost:27017')


    def add_player(self, name, email):
        self._clear_players()
        player = { "name": name, "email": email, "active": 1, "right_answers": 0 }
        return self._insert(player)


    def get_by_email(self, email):
        return self._get({"email": email})


    def get_by_id(self, userid):
        return self._get({"_id": userid})


    def get_current(self):
        return self._get({"active": 1})


    def update_score(self, data):
        current = self.get_current()
        self._update(current["_id"],  data)

    
    def _clear_players(self):
        conn = self._connect()
        db = conn[self.db_name]
        
        players = db["players"]
        obj_id = players.update_many({"active": 1}, {"$set": {"active": 0}})
        
        conn.close()


    def _get(self, query):
        conn = self._connect()
        db = conn[self.db_name]
        
        players = db["players"]
        player = players.find_one(query)
        
        conn.close()

        return player

        
    def _update(self, player_id, data):
        conn = self._connect()
        db = conn[self.db_name]
        players = db["players"]
        players.find_one_and_update({"_id": player_id}, {"$set": data})
        
        conn.close()


    def _insert(self, data):
        conn = self._connect()
        db = conn[self.db_name]
        
        players = db["players"]
        obj_id = players.insert_one(data).inserted_id
        
        conn.close()
        
        return obj_id

