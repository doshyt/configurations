using (var context = new UserContext())
{
    var user = context.Users
        .FirstOrDefault(user => user.Id == 72);
    if (user == null) 
        return NotFound();
    return Ok(user)
}
