import pygame
import os

from core import FileReader, Stage, StageType
from gameobjects import PygameTextBox, CodeResults

from gameobjects import Dialog

from stages import GameOver, StageClear

from time import time
from datetime import timedelta

from core import DataManager


class LangChallengeBase(Stage):

    def __init__(self, screen, source_code_name, q_number):
        super(LangChallengeBase, self).__init__(screen)

        self._screen = screen
        code_path = os.path.join(os.curdir, "lang_challenge", source_code_name)
        answers_path = os.path.join(os.curdir, "lang_challenge", source_code_name+".answers")
        # don't scramble source code in Lang challenge
        self._source_code = FileReader(code_path, scrambled=False).get_source()
        self._source_code_answers = FileReader(answers_path).get_source_answers()

        self._sprite_group = pygame.sprite.LayeredUpdates()

        self._dialog_sprite_group = pygame.sprite.LayeredUpdates()
        self._exit_sprite_group = pygame.sprite.LayeredUpdates()

        background_path = os.path.join(os.curdir, "assets", "snow_game_backgrounds_lang_main.png")
        self._background = pygame.image.load(background_path)
        self._screen.blit(self._background, (0, 0))

        font_path = os.path.join(os.curdir, "fonts", "Roboto-Regular.ttf")
        self._source_code_font = pygame.font.Font(font_path, 36)

        font_path = os.path.join(os.curdir, "fonts", "Roboto-Bold.ttf")
        self.font = pygame.font.Font(font_path, 46)

        self._source_code_answers_font = pygame.font.Font(font_path, 40)

        self.last_time = pygame.time.get_ticks()

        blue = (47, 177, 211)

        self._code_results = CodeResults((1320, 500), (240, 300), blue, self._sprite_group)

        self._selected = []
        self._render_question_number(q_number)
        self._render_source_code()
        self._render_source_code_answers()

        self._is_correct = None

        self._error_dialog = Dialog("snow_game_dialog-d01-001.png", self._dialog_sprite_group)
        
        self._exit_dialog = Dialog("snow_game_dialog-d01-002.png", self._exit_sprite_group)

        self._close_dialogs = False

        self._tries_left = 3

        self._start_time = time()

        self._stage_name = None

        self._data_manager = DataManager(db_name="levelup_lang")

        self._elapsed_time = None

        self._is_answer_right = False

        self._correct_answer_is_given = False

        self._correct_answer_position = None

        self._time_of_completion = None

    @property
    def stage_name(self):
        return self._stage_name

    @stage_name.setter
    def stage_name(self, value):
        self._stage_name = value

    @property
    def is_answer_right(self):
        return self._is_answer_right

    def _render_question_number(self, q_number):
        pos_x, pos_y = (1620, 0)
        color = (47, 177, 211)
        q_number_label = self.font.render(q_number, 0, color)
        self._screen.blit(q_number_label, (pos_x, pos_y))

    def _render_source_code(self):

        pos_x, pos_y = (320, 240)

        for key in self._source_code.keys():
            color = (47, 177, 211)
            text = "{}".format(self._source_code[key][1])
            line = self._source_code_font.render(text, 0, color)
            self._screen.blit(line, (pos_x, pos_y))
            pos_y += 50

    def _render_source_code_answers(self, selection=None, correct=False, draw = True):

        positions = {
            1: (500, 780),
            2: (1080, 780),
            3: (500, 905),
            4: (1080, 905)
        }

        for key in self._source_code_answers.keys():

            # standard blue
            color = (47, 177, 211)
            if selection:

                if str(key) == str(selection):
                    if correct:
                        # green
                        color = (99, 209, 62)
                    else:
                        # red
                        color = (255, 62, 51)

            answer = self._source_code_answers[key][1]
            if "*" in answer:
                answer = answer[:-1]
            if draw:
                line = self._source_code_answers_font.render(answer, 0, color)
                self._screen.blit(line, positions[key])

    @property
    def type(self):
        return StageType.stage

    def _event_handler(self, event):

        _ANSWER_KEYS = [
            pygame.K_1,
            pygame.K_2,
            pygame.K_3,
            pygame.K_4,
            pygame.K_KP1,
            pygame.K_KP2,
            pygame.K_KP3,
            pygame.K_KP4
        ]

        _ANSWER_VALUES = [u'1', u'2', u'3', u'4']

    #                done = True

        if event == pygame.event.Event(pygame.USEREVENT+1, {}):
            if self._is_correct in [True, False]:
                self._animate_answer()

        if event.type != pygame.KEYDOWN:
            return
        else:
            print "KEY is " + str(event)

        if not self._is_correct and self._error_dialog.visible:
            self._close_dialogs = True

        if event.unicode in _ANSWER_VALUES:

            typed_value = int(event.unicode)
            print "Typed value: " + str(typed_value)
            data = self._source_code_answers.get(typed_value)
            print "data: " + str(data)

            source_code_line_number, source_code_line = data

            if not self._time_of_completion:
                self._time_of_completion = pygame.time.get_ticks()
                self._time_of_completion = pygame.time.get_ticks()

                self._answer_position = typed_value

                if "*" in source_code_line:

                    self._is_answer_right = True
                    current_data = self._data_manager.get_current()

                    try:
                        current_data = {"right_answers": str(int(current_data["right_answers"]) + 1)}
                        print current_data
                    except KeyError:
                        current_data = {"right_answers": "1"}

                    self._data_manager.update_score(current_data)

                    self.sub_stage = None
                    self._is_correct = True
                else:
                    self._is_correct = False

        elif event.key == pygame.K_n and self._exit_dialog.visible:
            self._close_dialogs = True

        elif event.key == pygame.K_y and self._exit_dialog.visible:
            self._completed = True
            self.leave_when_completed = True

        elif event.key == pygame.K_ESCAPE and not self._error_dialog.visible:
            self._exit_dialog.visible = True

    def _animate_answer(self):

        now = pygame.time.get_ticks()

        if self._get_ticks_diff(now) > 1250:
            self._completed = True
            return
        elif self._get_ticks_diff(now) > 1000:
            self._render_source_code_answers(selection=self._answer_position, correct=self._is_answer_right)
        elif self._get_ticks_diff(now) > 750:
            self._render_source_code_answers()
        elif self._get_ticks_diff(now) > 500:
            self._render_source_code_answers(selection=self._answer_position, correct=self._is_answer_right)
        elif self._get_ticks_diff(now) > 250:
            self._render_source_code_answers()
        else:
            self._render_source_code_answers(selection=self._answer_position, correct=self._is_answer_right)


    def _get_ticks_diff(self, now):
        return int(now) - int(self._time_of_completion)

    def update(self, event):

        self._event_handler(event)

        if self._close_dialogs and self._error_dialog.visible:
            self._error_dialog.visible = False
            self._close_dialogs = False
            self._dialog_sprite_group.clear(self._screen, self._background)
            self._render_source_code()
            self._render_source_code_answers()

        if self._close_dialogs and self._exit_dialog.visible:
            self._exit_dialog.visible = False
            self._close_dialogs = False
            self._exit_sprite_group.clear(self._screen, self._background)
            self._render_source_code()
            self._render_source_code_answers()

        for sprite in self._sprite_group.sprites():
            sprite.handle_events(event)

        self._sprite_group.clear(self._screen, self._background)
        #self._render_source_code_answers()
        self._sprite_group.update(0.123 / 1000.)
        self._sprite_group.draw(self._screen)
        self._render_source_code()


        if self._exit_dialog.visible and not self._error_dialog.visible:
            self._exit_sprite_group.update(0.123 / 1000.)
            self._exit_sprite_group.draw(self._screen)

        if self._error_dialog.visible:
            self._dialog_sprite_group.update(0.123 / 1000.)
            self._dialog_sprite_group.draw(self._screen)

