import pygame
import os

from core import Stage, StageType, DataManager


class LangCongratsBase(Stage):

    def __init__(self, screen, num_of_challenges, *args):
        super(LangCongratsBase, self).__init__(screen)

        self._number_of_challenges = num_of_challenges
        self._screen = screen
        font_path = os.path.join(os.curdir, "fonts", "Roboto-Bold.ttf")
        self._font_congratz = pygame.font.Font(font_path, 55)
        self._font = pygame.font.Font(font_path, 48)

        bg_path = os.path.join(os.curdir, "assets", "snow_game_backgrounds_lang_end.png")
        bg = pygame.image.load(bg_path)
        screen.blit(bg, (0,0))

        self._data_manager = DataManager(db_name="levelup_lang")

        blue = (47, 177, 211)

        positions = {"total_score": (400, 690),
                     "total_time": (400, 490),
                     "congratz": (400, 290)}


        # if there is no correct answer - put 0
        try:
            score_from_db = self._data_manager.get_current()["right_answers"]
        except KeyError:
            self._data_manager.update_score({"right_answers": "0"})
            score_from_db = "0"
        try:
            time_from_db = self._data_manager.get_current()["time"]
        except KeyError:
            raise

        result_congratz_message = "Game over! We hope you've had fun :)"

        percentage_correct = (float(score_from_db)/float(self._number_of_challenges))*100
        print percentage_correct
        if percentage_correct >= 95.0:
            result_congratz_message = "Is it for real? Your result is perfect! Are you a human?"
        elif percentage_correct >= 90.0:
            result_congratz_message = "Great job! You must be a guru of languages!"
        elif percentage_correct >= 80.0:
            result_congratz_message = "Congratulations! Goooooooooood work!"
        elif percentage_correct >= 70.0:
            result_congratz_message = "Nicely done! Programming is your passion, isn't it?"
        elif percentage_correct >= 60.0:
            result_congratz_message = "Nice try! But we did our best to make it hard >:D"
        elif percentage_correct == 50.0:
            result_congratz_message = "It is over! Just in between of right and wrong!"

        elif percentage_correct < 10:
            result_congratz_message = "Game over! Didn't go well, huh?"

        congratz = self._font_congratz.render(result_congratz_message, 0, blue)
        self._screen.blit(congratz, positions["congratz"])

        total_time = self._font.render("Your time is: " + time_from_db+"s", 0, blue)
        self._screen.blit(total_time, positions["total_time"])

        total_score = self._font.render("Your final score is: " + str(score_from_db)+"/"+str(self._number_of_challenges), 0, blue)
        self._screen.blit(total_score, positions["total_score"])




    @property
    def type(self):
        return StageType.stage

    def update(self, event):
        self._event_handler(event)


    def _event_handler(self, event):

        if event.type != pygame.KEYDOWN:
            return

        if event.key == pygame.K_RETURN or event.key == pygame.K_ESCAPE:
            self._completed = True
            self.leave_when_completed = True

            

