(function($) {
  var getUser = function(userId) {
    return $.get('/api/user', {id: userId})
  }
  getUser(1).then(function(user) { 
      console.log(user.name)
  });
}(JQuery));
