from enum import Enum

StageType = Enum('splash_screen', 'registration', 'cut_scene', 'stage', 'sub_stage')
