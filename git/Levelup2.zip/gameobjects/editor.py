import pygame

class Editor(pygame.Surface):

    def __init__(self, dimensions, color, flags=pygame.HWSURFACE):
        super(Editor, self).__init__(dimensions, flags)
        self.fill(color)

    def update(self, event):
        pass
