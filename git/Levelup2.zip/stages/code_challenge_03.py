from gameobjects import CodeChallengeBase 


class CodeChallenge03(CodeChallengeBase):

    def __init__(self, screen, *args):
        super(CodeChallenge03, self).__init__(screen, "javascript_challenge.js")
        self.stage_name = "challenge_003"
