import random


class FileReader(object):

    def __init__(self, path, scrambled=True):
        self._path = path
        self._scrambled = scrambled
        self._code = self._read_source_code()
        self._answers = self._read_source_answers()

    def get_source(self):
        """
            Just a helper method to get the source code dictionary.
        """
        return self._code

    def get_source_answers(self):
        return self._answers

    def _read_source_code(self):
        """
            Read the source code file and generate and dictionary where
            the key is the scrambled line code and the value is a tuple
            with the correct line number and the code line.
        """
        filecontent = []

        # [x[:-1] to exclude line break, where the perl chomp function???
        with open(self._path) as f:
            filecontent = [x.rstrip() for x in f.readlines()]

        intermediate_source = zip(range(1, len(filecontent) + 1), filecontent)
    
        lines = range(1, len(filecontent) + 1)
        if self._scrambled:
            random.shuffle(lines)
            random.shuffle(lines)

        return dict(zip(lines, intermediate_source))

    def _read_source_answers(self):
        """
            Read the source code file and generate and dictionary where
            the key is the scrambled line code and the value is a tuple
            with the correct line number and the code line.
        """
        filecontent = []

        # [x[:-1] to exclude line break, where the perl chomp function???
        with open(self._path) as f:
            filecontent = [x.rstrip() for x in f.readlines()]

        intermediate_source = zip(range(1, len(filecontent) + 1), filecontent)
    
        lines = range(1, len(filecontent) + 1)
        random.shuffle(lines)
        random.shuffle(lines)

        return dict(zip(lines, intermediate_source))