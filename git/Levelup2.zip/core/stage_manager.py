import time
import random

from core import StageType
from datetime import timedelta
from .data_manager import DataManager


class StageManager(object):
    """
    Class to manage stages, it will take care of calling the update on every stage,
    move to next stages and so on.
    """
    def __init__(self, screen, initial_stage=0):
        self._screen = screen
        self._stage_map = []
        self._current_stage_index = initial_stage
        self._current_stage = None
        self._lang_correct_answers = 0
        self.number_of_challenges = 0
        # TODO: make db_name a parameter basing on which type of game we have
        self._data_manager = DataManager(db_name="levelup_lang")
        self._start_time = None
        self._end_time = None
        self._stage_position_map = []
        self._lang_tasks_map = []

    def randomize_questions(self, length, total_number_of_challenges):
        list_of_shuffled_positions = list(range(0, total_number_of_challenges))
        random.shuffle(list_of_shuffled_positions)
        print list_of_shuffled_positions
        if not length:
            self.lang_tasks_map = list_of_shuffled_positions
        else:
            self.lang_tasks_map = list_of_shuffled_positions[:length]

    def add(self, stage):
        self._stage_map.append(stage)
        print self._stage_map

    def start(self):
        """
        Start the current stage on the queue
        """

        if len(self._stage_map) <= 0:
            raise Exception("There are no stages registered.")

        stage_instance = self._stage_map[self._current_stage_index]

        if stage_instance is None:
            raise Exception("Couldn't find the stage.")

        self._exec_stage(stage_instance)

    def start_time(self):
        self._start_time = time.time()

    def stop_and_save_time(self):
        self._end_time = time.time()
        time_passed = self._end_time - self._start_time
        data = {"time": str(timedelta(seconds=time_passed))}
        self._data_manager.update_score(data)

    def _exec_stage(self, instance):
        print "Stage map: " + str(self._stage_map)
        callee = self._current_stage

        if str(instance.__name__) == "LangChallengeGeneric":
            # if registration is passed
            if callee.type == StageType.registration:
                self.start_time()
            q_number = "{}/{}".format(str(self._lang_tasks_map.index(self._current_stage_from_pos) + 1),
                                      self.number_of_challenges)
            self._current_stage = instance(self._screen, self._current_stage_from_pos, q_number, callee)
        elif self.is_last_stage() and callee.__class__.__name__ == "LangChallengeGeneric":
                # do it only if we play LangGame
                self.stop_and_save_time()
                self._current_stage = instance(self._screen, number_of_challenges=self.number_of_challenges)
        else:
            self._current_stage = instance(self._screen, callee)

    """
        Call update on the current stage, if the stage is complete it will
        advance to the next stage.
    """
    def update(self, tick):
        self._current_stage.update(tick)

        if self._current_stage.type != StageType.splash_screen and self._current_stage.type != StageType.registration:
            quit_update = self.quit_or_retry()
            if quit_update:
                return

        if self._current_stage.is_complete():
            if self._current_stage.type == StageType.stage and self._current_stage.is_answer_right:
                self._lang_correct_answers += 1
                print self._lang_correct_answers
            if self._current_stage.leave_when_completed:
                self._current_stage_index = 0
                self.start()
                return

            self._current_stage.sub_stage = None
            self._next_stage()

        if self._current_stage.is_complete() and self._current_stage.type != StageType.sub_stage:
            if hasattr(self._current_stage, 'move_next_when_completed'):
                self._next_stage()
                return

            self.start()
            self._current_stage.sub_stage = None

        if self._current_stage.sub_stage is not None:
            self._exec_stage(self._current_stage.sub_stage)

    def quit_or_retry(self):

        prevent_stage_change = False

        if self._current_stage.is_complete() and self._current_stage.leave_when_completed:
            self._current_stage_index = 0
            self.randomize_questions(self.number_of_challenges, self.number_of_challenges)
            self.start()
            prevent_stage_change = True

        if self._current_stage.is_complete() and self._current_stage.retry_when_completed:
            self._current_stage_index = 2
            self.start()
            prevent_stage_change = True

        return prevent_stage_change

    """
        Helper function to verify if the stage is the last one on the queue.
    """
    def is_last_stage(self):
        return (len(self._stage_map) - 1) == self._current_stage_index

    def is_conratz_stage(self):
        return (len(self._stage_map) - 2) == self._current_stage_index

    """
        Advance the next stage on the queue.
    """
    def _next_stage(self):
        print "moving to next stage from stage number " + str(self._current_stage_index)
        if not self.is_last_stage():
            self._current_stage_index += 1
            print "current stage map: " + str(self._lang_tasks_map)
            if self._current_stage_index-2 < len(self._lang_tasks_map):
                self._current_stage_from_pos = self._lang_tasks_map[self._current_stage_index-2]
                print "should appear stage " + str(self._current_stage_from_pos)
            self.start()

    """
        Returns the stage type (splash_screen, cut_scene, stage)
        See core.StageTypes for more details.
    """
    @property
    def current_stage_type(self):
        return self._current_stage.type

    """
        Handle events for all the registered stages.
    """
    def handle_events(self, event):
        if not self._current_stage.is_complete():
            self._current_stage._event_handler(event)

    @property
    def lang_tasks_map(self):
        return self._lang_tasks_map

    @lang_tasks_map.setter
    def lang_tasks_map(self, lang_map):
        self._lang_tasks_map = lang_map

